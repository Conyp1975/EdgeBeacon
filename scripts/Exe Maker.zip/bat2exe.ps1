param(
  [Parameter(Mandatory=$true)][string]$InputBat,      # e.g. .\scripts\Auto Reload Until Website is Up.bat
  [string]$OutputExe,                                 # e.g. .\EdgeBeacon.exe (default: same name .exe)
  [string]$Icon,                                      # e.g. .\scripts\icon\edgebeacon.ico  (optional)
  [switch]$WinExe                                     # use Windows GUI subsystem (no console)
)

if (-not (Test-Path $InputBat)) { Write-Error "Input BAT not found: $InputBat"; exit 1 }
if (-not $OutputExe) { $OutputExe = [IO.Path]::ChangeExtension((Resolve-Path $InputBat), ".exe") }

# Read BAT to Base64
$bytes = [IO.File]::ReadAllBytes((Resolve-Path $InputBat))
$b64 = [Convert]::ToBase64String($bytes)

# C# stub (writes BAT to temp, runs `cmd /c`, forwards args)
$src = @"
using System;
using System.IO;
using System.Diagnostics;

class Program {
  static int Main(string[] args) {
    try {
      string b64 = @"$b64";
      byte[] data = Convert.FromBase64String(b64);
      string tmp = Path.Combine(Path.GetTempPath(), "bat2exe_" + Guid.NewGuid().ToString("N"));
      Directory.CreateDirectory(tmp);
      string bat = Path.Combine(tmp, "payload.bat");
      File.WriteAllBytes(bat, data);

      string argLine = "";
      if (args != null && args.Length > 0) {
        foreach (var a in args) {
          if (a == null) continue;
          string escaped = a.Replace("\"", "\\\"");
          argLine += " \"" + escaped + "\"";
        }
      }

      var psi = new ProcessStartInfo("cmd.exe", "/c \"" + bat + "\"" + argLine) {
        UseShellExecute = false,
        RedirectStandardOutput = false,
        RedirectStandardError = false,
        WorkingDirectory = tmp,
        CreateNoWindow = false
      };
      var p = Process.Start(psi);
      p.WaitForExit();
      int code = p.ExitCode;
      try { Directory.Delete(tmp, true); } catch {}
      return code;
    } catch (Exception ex) {
      Console.Error.WriteLine(ex.ToString());
      return 1;
    }
  }
}
"@

# Write temp .cs
$srcPath = Join-Path $env:TEMP ("batstub_" + [guid]::NewGuid().ToString("N") + ".cs")
[IO.File]::WriteAllText($srcPath, $src)

# Locate csc.exe (.NET Framework 4.x)
$fw = Get-ChildItem "$env:WINDIR\Microsoft.NET\Framework64\v4*" -Directory -ErrorAction SilentlyContinue |
      Sort-Object -Descending | Select-Object -First 1
if (-not $fw) {
  $fw = Get-ChildItem "$env:WINDIR\Microsoft.NET\Framework\v4*" -Directory -ErrorAction SilentlyContinue |
        Sort-Object -Descending | Select-Object -First 1
}
if (-not $fw) { Write-Error "Could not locate csc.exe (.NET Framework v4+)"; exit 1 }

$csc = Join-Path $fw.FullName "csc.exe"

# Target type (PS5.1 safe)
$target = "exe"
if ($WinExe.IsPresent) { $target = "winexe" }

# Build args
$args = @("/nologo","/optimize+","/target:$target","/out:$OutputExe",$srcPath)
if ($Icon) { $args += "/win32icon:$Icon" }

& $csc @args
$exit = $LASTEXITCODE

Remove-Item $srcPath -ErrorAction SilentlyContinue

if ($exit -ne 0) { Write-Error "Compilation failed (exit $exit)"; exit $exit }
Write-Host "OK: Built $OutputExe"
